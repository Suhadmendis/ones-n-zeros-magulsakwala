<?php
return [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'magulsakwala_dev',
    'db_user' => 'root',
    'db_pass' => '',
];
