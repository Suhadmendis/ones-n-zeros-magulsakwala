<?php
// Upload this file to the server as api/config.php — do not commit, do not use locally.

return [
    'db_host' => '209.42.255.1',
    'db_port' => 3306,
    'db_name' => 'onesnzer_magulsakwala',
    'db_user' => 'onesnzer_akila',
    'db_pass' => 'SaGaRa4000',
];
